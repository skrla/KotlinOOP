package t2ucahurivanje

class Start {

    private var dokument: Dokument

    init {
        dokument = Dokument()
        dokument.sifra = 1
        dokument.brojDokumenta = "2020-001"
        dokument.iznos = 1200.34
        println(dokument.opisiMe())

        dokument = Dokument(2, "2020-002", 100.toDouble(), Osoba(1, "Tomislav", "Jakopec"))
        println(dokument.opisiMe())

        println(Dokument(3, "2020-003", 200.toDouble(), Osoba(1, "Pero", "Perić")).opisiMe())
    }
}

fun main() {
    Start()
}