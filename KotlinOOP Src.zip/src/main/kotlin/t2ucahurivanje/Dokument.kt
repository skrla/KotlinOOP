package t2ucahurivanje

public class Dokument() {

    var sifra: Int = 0
    lateinit var brojDokumenta: String
    var iznos: Double = 0.0
    private lateinit var izradio: Osoba

    constructor(sifra: Int, brojDokumenta: String, iznos: Double, izradio: Osoba) : this() {
        this.sifra = sifra
        this.brojDokumenta = brojDokumenta
        this.iznos = iznos
        this.izradio = izradio
    }

    public fun opisiMe(): String {
        return "$sifra - $brojDokumenta - $iznos"
    }

}