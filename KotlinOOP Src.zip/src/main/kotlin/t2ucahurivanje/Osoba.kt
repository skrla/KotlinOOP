package t2ucahurivanje

public class Osoba() {

    private var sifra: Int = 0
    private lateinit var ime: String
    private lateinit var prezime: String

    constructor(sifra: Int, ime: String, prezime: String) : this() {
        this.sifra = sifra
        this.ime = ime
        this.prezime = prezime
    }
}