package t4polimorfizam

public abstract class Dokument() : Any() {

    var sifra = 0
    lateinit var brojDokumenta: String
    var iznos = 0.0
    var izradio: Osoba? = null

    abstract fun obradiDokument()
    abstract fun getOpis(): String?

    constructor(sifra: Int, brojDokumenta: String, iznos: Double, izradio: Osoba?) : this() {
        this.sifra = sifra
        this.brojDokumenta = brojDokumenta
        this.iznos = iznos
        this.izradio = izradio
    }

    override fun toString(): String {
        return "Dokument{ sifra=$sifra, brojDokumenta='$brojDokumenta', iznos=$iznos}"
    }

}