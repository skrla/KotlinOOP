package t4polimorfizam

public class RadniNalog(var radnik: Osoba? = null) : Dokument() {

    override fun obradiDokument() = println("Obrađujem radni nalog")
    override fun getOpis(): String? = null

}