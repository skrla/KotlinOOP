package t4polimorfizam

class Racun() : Dokument() {

    lateinit var kupac: String

    override fun obradiDokument() = println("Obrađujem račun")

    override fun getOpis() = null

    constructor(sifra: Int, brojDokumenta: String, iznos: Double, kupac: String) : this() {
        this.sifra = sifra
        this.brojDokumenta = brojDokumenta
        this.iznos = iznos
        this.kupac = kupac
    }

    override fun toString(): String {
        return "Racun{ kupac='$kupac'} koji nasljeđuje ${super.toString()}"
    }

}