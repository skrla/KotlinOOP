package t4polimorfizam

import java.util.function.Consumer


public class Start {

    private var dokumenti: MutableList<Dokument>? = null

    init {

        dokumenti = mutableListOf()
        val radniNalog = RadniNalog()
        radniNalog.sifra = 1
        radniNalog.brojDokumenta = "RN1"
        radniNalog.iznos = 1200.toDouble()
        radniNalog.radnik = Osoba(1, "Marko", "Markovina")
        println(radniNalog)
        dokumenti!!.add(radniNalog)
        val racun = Racun()
        racun.sifra = 1
        racun.brojDokumenta = "2020-001"
        racun.iznos = 1200.34
        racun.kupac = "FFOS"
        println(racun)
        dokumenti!!.add(racun)
        obradiDokumente()
    }

    private fun obradiDokumente() {
        println("forEach funkcija")
        dokumenti!!.forEach(Consumer { d: Dokument -> d.obradiDokument() })

        //ako nekog buni gornja sintaksa evo još dvije
        println("for petlja")
        for (i in dokumenti!!.indices) {
            dokumenti!![i].obradiDokument()
        }
        println("foreach petlja")
        for (d in dokumenti!!) {
            d.obradiDokument()
        }
    }
}

fun main() {
    Start()
}