package t3nasljedivanje

public class Racun() : Dokument() {

    lateinit var kupac: String

    constructor(sifra: Int, brojDokumenta: String, iznos: Double, kupac: String) : this() {
        Dokument(sifra, brojDokumenta, iznos, null)
        this.kupac = kupac
    }
}