package t3nasljedivanje

public class Start {

    init {
        val n = Nova()
        println(n)
        val dokument = Dokument()
        dokument.sifra = 1
        dokument.brojDokumenta = "D1"
        dokument.iznos = 200.toDouble()
        println(dokument)
        val radniNalog = RadniNalog()
        radniNalog.sifra = 1
        radniNalog.brojDokumenta = "RN1"
        radniNalog.iznos = 1200.toDouble()
        radniNalog.radnik = Osoba(1, "Marko", "Markovina")
        println(radniNalog)
        val racun = Racun()
        racun.sifra = 1
        racun.brojDokumenta = "2020-001"
        racun.iznos = 1200.34
        racun.kupac = "FFOS"
        println(racun)

    }
}

fun main() {
    Start()
}