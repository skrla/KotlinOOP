package t3nasljedivanje

public class Osoba() {

    var sifra = 0
    lateinit var ime: String
    lateinit var prezime: String

    constructor(sifra: Int, ime: String, prezime: String) : this() {
        this.sifra = sifra
        this.ime = ime
        this.prezime = prezime
    }
}