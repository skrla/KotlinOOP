package t3nasljedivanje

class RadniNalog() : Dokument() {

    lateinit var radnik: Osoba

    constructor(radnik: Osoba) : this() {
        this.radnik = radnik
    }
}