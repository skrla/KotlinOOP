package t3nasljedivanje

public class Nova {

    lateinit var ime: String

    override fun toString(): String {
        return "Predstavio sam se"
    }
}