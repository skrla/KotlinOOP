import model.*
import pomocno.Json

class Start {
    private var partije: MutableList<Partija> = mutableListOf()
    private var igrac1: Igrac? = null
    private var igrac2: Igrac? = null
    private var igrac3: Igrac? = null
    private var igrac4: Igrac? = null
    private var lokacija: Lokacija? = null

    init {
        kreirajRucno()
        Json.toJsonFile("podaci.json", partije)
    }

    private fun kreirajRucno() {
        partije = ArrayList()
        igrac1 = kreirajIgraca1()
        igrac2 = kreirajIgraca2()
        igrac3 =
            Igrac(3, "Marija", "Zimska", "https://picsum.photos/200", Spol.ZENSKO.id)
        igrac4 =
            Igrac(4, "Anita", "Račman", "https://picsum.photos/200", Spol.ZENSKO.id)
        lokacija = kreirajLokaciju()
        kreirajPartijuDvaIgraca()
        kreirajPartijuTriIgraca()
        kreirajPartijuDvaPara()
    }

    private fun kreirajPartijuDvaPara() {
        val partija = PartijaDvaPara()
        partija.doKolikoSeIgra = 501
        partija.lokacija = lokacija!!
        partija.unosi = igrac1!!
        val igraci: MutableList<Igrac?> = mutableListOf()
        igraci += igrac1
        igraci += (igrac2)
        igraci += (igrac3)
        igraci += (igrac4)
        partija.igraci = igraci
        println(partije.joinToString())
        partija.mjesanja = kreirajMjesanjaDvaPara()
        partije.add(partija)
    }

    private fun kreirajMjesanjaDvaPara(): List<Mjesanje> {
        val mjesanja: MutableList<Mjesanje> = ArrayList()
        var m = MjesanjeDvaUnosa()
        m.bodovaPrviUnos = 10
        m.bodovaDrugiUnos = 152
        m.zvanjePrviUnos = 0
        m.zvanjeDrugiUnos = 20
        mjesanja.add(m)
        m = MjesanjeDvaUnosa()
        m.bodovaPrviUnos = 152
        m.bodovaDrugiUnos = 10
        m.zvanjePrviUnos = 0
        m.zvanjeDrugiUnos = 20
        m.stiglja = true
        mjesanja.add(m)
        return mjesanja
    }

    private fun kreirajPartijuTriIgraca() {
        val partija = PartijaTriIgraca()
        partija.doKolikoSeIgra = 501
        partija.lokacija = lokacija!!
        partija.unosi = igrac1!!
        val igraci: MutableList<Igrac?> = mutableListOf()
        igraci.add(igrac1)
        igraci.add(igrac2)
        igraci.add(igrac3)
        partija.igraci = igraci
        partija.mjesanja = kreirajMjesanjaTriIgraca()
        partije.add(partija)
    }

    private fun kreirajMjesanjaTriIgraca(): List<Mjesanje> {
        val mjesanja: MutableList<Mjesanje> = mutableListOf()
        var m = MjesanjeTriUnosa()
        m.bodovaPrviUnos = 10
        m.bodovaDrugiUnos = 76
        m.zvanjePrviUnos = 0
        m.zvanjeDrugiUnos = 20
        m.bodovaTreciUnos = 76
        mjesanja.add(m)
        for (i in 0..4) {
            m = MjesanjeTriUnosa()
            m.bodovaPrviUnos = 10
            m.bodovaDrugiUnos = 76
            m.zvanjePrviUnos = 0
            m.zvanjeDrugiUnos = 20
            m.bodovaTreciUnos = 76
            mjesanja.add(m)
        }
        return mjesanja
    }

    private fun kreirajPartijuDvaIgraca() {
        val partija = PartijaDvaIgraca()
        partija.doKolikoSeIgra = 501
        partija.lokacija = lokacija!!
        partija.unosi = igrac1!!
        val igraci: MutableList<Igrac?> = mutableListOf()
        igraci.add(igrac1)
        igraci.add(igrac2)
        partija.igraci = igraci
        partija.mjesanja = kreirajMjesanjaDvaIgraca()
        partije.add(partija)
    }

    private fun kreirajMjesanjaDvaIgraca(): List<Mjesanje> {
        val mjesanja: MutableList<Mjesanje> = ArrayList()
        var m = MjesanjeDvaUnosa()
        m.bodovaPrviUnos = 10
        m.bodovaDrugiUnos = 152
        m.zvanjePrviUnos = 0
        m.zvanjeDrugiUnos = 20
        mjesanja.add(m)
        m = MjesanjeDvaUnosa()
        m.bodovaPrviUnos = 152
        m.bodovaDrugiUnos = 10
        m.zvanjePrviUnos = 0
        m.zvanjeDrugiUnos = 20
        m.stiglja = true
        mjesanja.add(m)
        return mjesanja
    }

    private fun kreirajLokaciju(): Lokacija {
        val l = Lokacija()
        l.id = 1
        l.naziv = "Caffe Bar Peppermint"
        l.latitude = 45.5605825
        l.longitude = 18.6098766
        return l
    }

    private fun kreirajIgraca1(): Igrac {
        val i = Igrac()
        i.id = 1
        i.ime = "Tomislav"
        i.prezime = "Jakopec"
        i.urlSlike = "https://picsum.photos/200"
        i.spol = Spol.MUSKO.id
        return i
    }

    private fun kreirajIgraca2(): Igrac {
        val i = Igrac()
        i.id = 2
        i.ime = "Marijan"
        i.prezime = "Zidar"
        i.urlSlike = "https://picsum.photos/200"
        i.spol = Spol.MUSKO.id
        return i
    }
}

fun main() {
    Start()
}