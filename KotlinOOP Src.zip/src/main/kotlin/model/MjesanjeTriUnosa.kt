package model

public class MjesanjeTriUnosa : MjesanjeDvaUnosa() {

    var bodovaTreciUnos = 0

    var zvanjeTreciUnos = 0

    override fun getRezultat(): Rezultat {
        val treciRezultat = super.getRezultat()
        treciRezultat!!.treci = bodovaTreciUnos + zvanjeTreciUnos
        return treciRezultat
    }
}