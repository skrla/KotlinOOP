package model

enum class Spol(val id: Int) {
    ZENSKO(0),
    MUSKO(1);

}