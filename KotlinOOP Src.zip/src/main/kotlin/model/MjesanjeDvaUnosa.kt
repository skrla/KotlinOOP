package model

public open class MjesanjeDvaUnosa : Mjesanje() {

    var bodovaPrviUnos = 0
    var bodovaDrugiUnos = 0

    var zvanjePrviUnos = 0
    var zvanjeDrugiUnos = 0

    override fun getRezultat(): Rezultat? {
        return Rezultat(bodovaPrviUnos + zvanjePrviUnos, bodovaDrugiUnos + zvanjeDrugiUnos)
    }
}