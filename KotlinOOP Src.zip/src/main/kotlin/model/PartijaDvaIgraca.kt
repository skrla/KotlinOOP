package model

public open class PartijaDvaIgraca : Partija() {

    override fun toString(): String {
        val rezultat= getRezultat()
        return "Partija DVA IGRAČA, igra gotova: " + isIgraGotova() + ", " + igraci[0] + ": " +
                rezultat.prvi +
                " | " + igraci[1] + ": " + rezultat.drugi
    }
}