package model

class Lokacija() : Entitet() {

    var longitude: Double = 0.0
    var latitude: Double = 0.0
    lateinit var naziv: String

    constructor(longitude: Double, latitude: Double, naziv: String) : this() {
        this.longitude = longitude
        this.latitude = latitude
        this.naziv = naziv
    }

}