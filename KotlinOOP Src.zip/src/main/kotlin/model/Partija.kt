package model

import java.util.function.ToIntFunction

public abstract class Partija : Entitet() {

    var doKolikoSeIgra = 0
    var lokacija: Lokacija = Lokacija()
    var unosi: Igrac = Igrac()
    var mjesanja: List<Mjesanje> = listOf()
    var igraci: MutableList<Igrac?> = mutableListOf()

    open fun getRezultat(): Rezultat {
        return Rezultat(
            mjesanja.stream().mapToInt(ToIntFunction<Mjesanje> { it: Mjesanje -> it.getRezultat()!!.prvi }).sum(),
            mjesanja.stream().mapToInt(ToIntFunction<Mjesanje> { it: Mjesanje -> it.getRezultat()!!.drugi }).sum()
        )
    }

    public fun isIgraGotova(): Boolean {
        val rezultat = getRezultat()
        if (rezultat.isPocetak()) {
            return false
        }
        if (rezultat.treci == 0) {
            return if (rezultat.prvi == rezultat.drugi) false else rezultat.prvi > doKolikoSeIgra || rezultat.drugi > doKolikoSeIgra
        } else {
            if (rezultat.prvi == rezultat.drugi || rezultat.prvi == rezultat.treci || rezultat.drugi == rezultat.treci) {
                return false
            }
            if (rezultat.prvi > doKolikoSeIgra || rezultat.drugi > doKolikoSeIgra || rezultat.treci > doKolikoSeIgra) {
                return true
            }
        }
        return false
    }
}