package model

public abstract class Entitet(var id: Int = 0)