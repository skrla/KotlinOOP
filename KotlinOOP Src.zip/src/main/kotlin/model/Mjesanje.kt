package model

import java.util.*

public abstract class Mjesanje : Entitet() {

    var stiglja = false
    var belot = false
    var datumUnosa: Date? = null

    public abstract fun getRezultat(): Rezultat?

}