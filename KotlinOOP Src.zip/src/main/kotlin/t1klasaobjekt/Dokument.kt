package t1klasaobjekt

class Dokument {
    init {
        println("Konstruiram novu instancu klase Dokument")
    }
}

