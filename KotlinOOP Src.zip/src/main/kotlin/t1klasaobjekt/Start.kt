package t1klasaobjekt

fun main() {
    Dokument()
}